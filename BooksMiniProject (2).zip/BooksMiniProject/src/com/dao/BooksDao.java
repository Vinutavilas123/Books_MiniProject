package com.dao;



import java.util.Iterator;
import java.util.Optional;
import java.util.Scanner;

import com.db.Database;
import com.service.Books;

public class BooksDao {
	
	Database obj = new Database();
	Books book;
	public int getCh() {
		return ch;
	}

	public void setCh(int ch) {
		this.ch = ch;
	}

	Scanner sc = new Scanner(System.in);
	int ch;
	public void showMenu() {
		System.out.println("Enter your choice : ");
		System.out.println("1. Display all the books ");
		System.out.println("2. Add a book ");
		System.out.println("3. Delete a book ");
		System.out.println("4. Update a book price");
		System.out.println("5. Find book by id ");
		System.out.println("6. Exit ");
	    ch = sc.nextInt();
	}
	
	public void add(Books b1) {
		
		obj.getBooks().add(b1);
		System.out.println(obj.getBooks());
		System.out.println("Press 0 for main menu :");
	    int c = sc.nextInt();
	    if(c == 0)
	    	this.showMenu();
	    else 
            ch = 6;
	    
	}
	
	public void findById(int id) {
		
		
		for(Books b: obj.getBooks()) {
			int Id = b.getBookId();
			if(Id == id)
				{book = b; 
				System.out.println(book);
				break;}
			else
				book = null;
			
		}
		System.out.println("Press 0 for main menu :");
	    int c = sc.nextInt();
	    if(c == 0)
	    	this.showMenu();
	    else
	    	ch = 6;
		
		
		
	}
	
	
	public void remove(int id) {
		
		Books b = this.book;
		obj.getBooks().remove(b);
		System.out.println(obj.getBooks());
		System.out.println("Press 0 for main menu :");
	    int c = sc.nextInt();
	    if(c == 0)
	    	this.showMenu();
	    else
	    	ch = 6;
		
	}
	
	public void update(int id) {
		
		System.out.println("Enter the updated price : ");
		Scanner sc = new Scanner(System.in);
		int pr = sc.nextInt();
		Books b = this.book;
		b.setPrice(pr);
		System.out.println(obj.getBooks());
		System.out.println("Press 0 for main menu :");
	    int c = sc.nextInt();
	    if(c == 0)
	    	this.showMenu();
	    else
	    	ch = 6;
		
	}

	public void displayAll() {
		System.out.println(obj.getBooks());
		System.out.println("Press 0 for main menu :");
	    int c = sc.nextInt();
	    if(c == 0)
	    	this.showMenu();
	    else
	    	ch = 6;
	}
}
