package com.ui;

import java.sql.SQLException;
import java.util.Scanner;


import com.dao.JdbcBooksDao;
import com.service.Books;

public class AdminJdbc {

	public static void main(String[] args) throws SQLException {
		JdbcBooksDao obj = new JdbcBooksDao();
		obj.showMenu();
		
		Scanner sc = new Scanner(System.in);
		
		int ch = obj.getCh();
		boolean val = true;
		
		while(val == true) {
		
		switch(ch) {
		
		case 1: obj.displayAll();
		        ch=obj.getCh();
		        break;
		case 2: System.out.println("Enter book id :");
			    int bid = sc.nextInt();
			    System.out.println("Enter book title: ");
			    String t = sc.next();
			    System.out.println("Enter book price : ");
			    int p = sc.nextInt();
			    System.out.println("Enter book author : ");
			    String a = sc.next();
			    Books b1 = new Books(bid, t, p, a);
			    obj.add(b1);
			    ch=obj.getCh();
			    break;
		case 3: System.out.println("Enter book id :");
	            int b = sc.nextInt();
	            obj.remove(b);
	            ch=obj.getCh();
	            break;
		case 4: System.out.println("Enter book id :");
	    		int b2 = sc.nextInt();
	    		obj.update(b2);
	    		break;
		case 5: System.out.println("Enter book id :");
		        int b3 = sc.nextInt();
		        obj.findById(b3);
		        break;
		case 6: val = false;
	    		
		}
		        
		        
		
		}
		

	}

}
